float pembagian(float a, float b) {
  return a / b;
}