int penjumlahan(int a, int b) {
  return a + b;
}